import { program } from 'commander';
import fs from 'fs-extra';
import chalk from 'chalk';
import path from 'path';
import { glob } from 'glob';

program
  .name('infra')
  .description('Infrastructure - file bundler and compressor')
  .version('1.0.0');

program
  .command('compress <input> <output>')
  .description('Compress a file or folder into a zip')
  .action(async function(input, output) {
    const archiver = (await import('archiver')).default;
    console.log(chalk.cyan('Compressing: ' + input));
    const outputStream = fs.createWriteStream(output);
    const archive = archiver('zip', { zlib: { level: 9 } });
    outputStream.on('close', function() {
      const size = archive.pointer();
      console.log(chalk.green('Done! ' + size + ' bytes written to ' + output));
    });
    archive.pipe(outputStream);
    archive.glob('**/*', { cwd: path.resolve(input) });
    archive.finalize();
  });

program
  .command('bundle <files...>')
  .description('Bundle multiple files into one')
  .option('-o, --output <output>', 'Output file name', 'bundle.txt')
  .action(function(files, options) {
    console.log(chalk.cyan('Bundling ' + files.length + ' files...'));
    let bundled = '';
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const content = fs.readFileSync(file, 'utf8');
      bundled += '// --- ' + file + ' ---\n';
      bundled += content + '\n\n';
      console.log(chalk.yellow('  Added: ' + file));
    }
    fs.writeFileSync(options.output, bundled);
    console.log(chalk.green('Done! Bundle saved to ' + options.output));
  });

program
  .command('pack <input>')
  .description('Pack a folder into an IDF file')
  .option('-o, --output <output>', 'Output file name', 'output.idf')
  .action(async function(input, options) {
    console.log(chalk.cyan('Packing: ' + input));
    const basePath = path.resolve(input);
    const files = await glob('**/*', { cwd: basePath, nodir: true });
    let fileTable = '';
    let fileData = '';
    for (let i = 0; i < files.length; i++) {
      const filePath = files[i];
      const fullPath = path.join(basePath, filePath);
      const content = fs.readFileSync(fullPath, 'utf8');
      const size = Buffer.byteLength(content, 'utf8');
      fileTable += i + ' | ' + filePath + ' | ' + size + ' bytes\n';
      fileData += '--- ' + filePath + ' ---\n';
      fileData += content + '\n';
      console.log(chalk.yellow('  Packed: ' + filePath));
    }
    const header =
      '[IDF HEADER]\n' +
      'version: 1.0\n' +
      'created: ' + new Date().toISOString() + '\n' +
      'files: ' + files.length + '\n\n';
    const table = '[FILE TABLE]\n' + fileTable + '\n';
    const data = '[FILE DATA]\n' + fileData;
    fs.writeFileSync(options.output, header + table + data);
    console.log(chalk.green('Done! Packed ' + files.length + ' files into ' + options.output));
  });

program
  .command('unpack <input>')
  .description('Unpack an IDF file into a folder')
  .option('-o, --output <output>', 'Output folder', './unpacked')
  .action(function(input, options) {
    console.log(chalk.cyan('Unpacking: ' + input));
    const content = fs.readFileSync(input, 'utf8');
    const dataSection = content.split('[FILE DATA]\n')[1];
    const fileBlocks = dataSection.split(/^--- /m).filter(Boolean);
    fs.ensureDirSync(options.output);
    for (let i = 0; i < fileBlocks.length; i++) {
      const block = fileBlocks[i];
      const firstNewline = block.indexOf('\n');
      const filePath = block.substring(0, firstNewline).replace(' ---', '').trim();
      const fileContent = block.substring(firstNewline + 1);
      const fullPath = path.join(options.output, filePath);
      fs.ensureDirSync(path.dirname(fullPath));
      fs.writeFileSync(fullPath, fileContent);
      console.log(chalk.yellow('  Unpacked: ' + filePath));
    }
    console.log(chalk.green('Done! Unpacked to ' + options.output));
  });

program
  .command('inspect <input>')
  .description('Inspect an IDF file without extracting')
  .action(function(input) {
    console.log(chalk.cyan('Inspecting: ' + input));
    const content = fs.readFileSync(input, 'utf8');
    const headerEnd = content.indexOf('[FILE DATA]');
    const preview = content.substring(0, headerEnd);
    console.log(chalk.white(preview));
  });

program.parse();
