import { program } from 'commander';
import fs from 'fs-extra';
import chalk from 'chalk';
import path from 'path';

program
  .name('vault')
  .description('Vault - file encryption using master key division')
  .version('1.0.0');

function keyValue(masterKey) {
  let total = 0;
  for (let i = 0; i < masterKey.length; i++) {
    total += masterKey.charCodeAt(i);
  }
  return total;
}

function encrypt(buffer, masterKey) {
  const kv = keyValue(masterKey);
  const quotients = [];
  const remainders = [];
  for (let i = 0; i < buffer.length; i++) {
    const byte = buffer[i];
    const q = Math.floor(byte / kv);
    const r = byte % kv;
    quotients.push(q);
    remainders.push(r);
  }
  return { quotients, remainders };
}

function decrypt(quotients, remainders, masterKey) {
  const kv = keyValue(masterKey);
  const result = [];
  for (let i = 0; i < quotients.length; i++) {
    const byte = (quotients[i] * kv) + remainders[i];
    result.push(byte);
  }
  return Buffer.from(result);
}

program
  .command('encrypt <input>')
  .description('Encrypt a file into a .vlt file')
  .option('-k, --key <key>', 'Master key')
  .option('-o, --output <output>', 'Output file', 'output.vlt')
  .action(function(input, options) {
    if (!options.key) { console.log(chalk.red('Error: master key required (-k "yourkey")')); return; }
    console.log(chalk.cyan('Encrypting: ' + input));
    const buffer = fs.readFileSync(input);
    const { quotients, remainders } = encrypt(buffer, options.key);
    const binaryValue = buffer.reduce((a, b) => a + b, 0);
    let out = '[VLT HEADER]\n';
    out += 'version: 1.0\n';
    out += 'source: ' + path.basename(input) + '\n';
    out += 'created: ' + new Date().toISOString() + '\n';
    out += 'bytes: ' + buffer.length + '\n';
    out += 'binary_value: ' + binaryValue + '\n\n';
    out += '[QUOTIENTS]\n';
    out += quotients.join(',') + '\n\n';
    out += '[REMAINDERS]\n';
    out += remainders.join(',') + '\n';
    let outPath = options.output;
    if (!outPath.endsWith('.vlt')) outPath += '.vlt';
    fs.writeFileSync(outPath, out);
    const originalSize = buffer.length;
    const encryptedSize = Buffer.byteLength(out, 'utf8');
    console.log(chalk.green('Done! Encrypted ' + originalSize + ' bytes → ' + outPath));
    console.log(chalk.green('Binary value of source: ' + binaryValue));
  });

program
  .command('decrypt <input>')
  .description('Decrypt a .vlt file')
  .option('-k, --key <key>', 'Master key')
  .option('-o, --output <output>', 'Output file', 'restored.txt')
  .action(function(input, options) {
    if (!options.key) { console.log(chalk.red('Error: master key required (-k "yourkey")')); return; }
    console.log(chalk.cyan('Decrypting: ' + input));
    const content = fs.readFileSync(input, 'utf8');
    const quotientSection = content.split('[QUOTIENTS]\n')[1].split('\n\n')[0].trim();
    const remainderSection = content.split('[REMAINDERS]\n')[1].trim();
    const quotients = quotientSection.split(',').map(Number);
    const remainders = remainderSection.split(',').map(Number);
    const restored = decrypt(quotients, remainders, options.key);
    fs.writeFileSync(options.output, restored);
    console.log(chalk.green('Done! Decrypted to ' + options.output));
  });

program
  .command('inspect <input>')
  .description('Inspect a .vlt file')
  .action(function(input) {
    console.log(chalk.cyan('Inspecting: ' + input));
    const content = fs.readFileSync(input, 'utf8');
    const header = content.split('[QUOTIENTS]')[0];
    console.log(chalk.white(header));
  });

program.parse();
